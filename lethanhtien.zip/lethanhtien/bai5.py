x = float(input("nhap so km da chay "))
if x<= 0:
   print("quang duong phai la so duong")
else:
   if x <= 1:
        tien_cuoc = x * 7000
   elif x <= 5:
       tien_cuoc = 7000 + ( x - 1) * 6500
   else:
       tien_cuoc = 7000 + ( 5 - 1 ) * 6500 + (x - 5 ) * 6000
   print(f"so tien phai tra la: {tien_cuoc}đ ")
