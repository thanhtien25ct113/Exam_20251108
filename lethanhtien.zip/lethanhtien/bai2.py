year = int(input("nhap mot nam nhat dinh"))
if (year % 4 == 0 and year % 100 == 0) or ( year % 400 == 0 ):
    print("nam" ,year, "la nam nhuan ")
else:
    print("nam" ,year, "khong phai nam nhuan ")