E = int(input("nhap mot nhiet do nhat dinh"))
if E > 30:
    print("troi dg nong")
elif E < 20:
    print("troi dang lanh")
else:
    print("thoi tiet de chiu")