A = input("ban hay nhap mat khau moi:")
B = input("ban hay nhap xac nhan mat khau moi lan 2:")
if  A!=B:
    print("mat khau khong giong nhau ")
else:
    print("mat khau da duoc doi thanh cong")